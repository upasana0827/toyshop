package com.toyshopapi.enums;

public interface CodeEnum {
    Integer getCode();

}
