package com.toyshopapi.service;

import java.util.Collection;

import com.toyshopapi.entity.Cart;
import com.toyshopapi.entity.ProductInOrder;
import com.toyshopapi.entity.User;

public interface CartService {
    Cart getCart(User user);

    void mergeLocalCart(Collection<ProductInOrder> productInOrders, User user);

    void delete(String itemId, User user);

    void checkout(User user);
}
