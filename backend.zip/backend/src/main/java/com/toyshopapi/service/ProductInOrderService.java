package com.toyshopapi.service;

import com.toyshopapi.entity.ProductInOrder;
import com.toyshopapi.entity.User;


public interface ProductInOrderService {
    void update(String itemId, Integer quantity, User user);
    ProductInOrder findOne(String itemId, User user);
}
